from . import db
from flask_login import UserMixin
from datetime import datetime

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_doctor = db.Column(db.Boolean, default=False)

    doctor_profile = db.relationship('DoctorProfile', backref='user', uselist=False)
    patient_profile = db.relationship('PatientProfile', backref='user', uselist=False)

class DoctorProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(120))
    specialty = db.Column(db.String(120))
    bio = db.Column(db.Text)

    cases = db.relationship('MedicalRecord', backref='doctor')
    appointments = db.relationship('Appointment', backref='doctor')

class PatientProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(120))
    dob = db.Column(db.Date)
    gender = db.Column(db.String(20))

    records = db.relationship('MedicalRecord', backref='patient')
    appointments = db.relationship('Appointment', backref='patient')

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor_profile.id'))
    patient_id = db.Column(db.Integer, db.ForeignKey('patient_profile.id'))
    scheduled_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)

class MedicalRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor_profile.id'))
    patient_id = db.Column(db.Integer, db.ForeignKey('patient_profile.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    summary = db.Column(db.Text)
