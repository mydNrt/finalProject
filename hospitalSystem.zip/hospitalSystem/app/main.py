from flask import Blueprint, render_template
from flask_login import current_user, login_required
from .models import DoctorProfile, PatientProfile

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    return render_template('index.html')


@main_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_doctor:
        profile = DoctorProfile.query.filter_by(user_id=current_user.id).first()
        return render_template('doctor_dashboard.html', profile=profile)
    else:
        profile = PatientProfile.query.filter_by(user_id=current_user.id).first()
        return render_template('patient_dashboard.html', profile=profile)
