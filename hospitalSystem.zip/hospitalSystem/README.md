Hospital System (Flask + Bootstrap)

Setup:
1. python -m venv venv
2. venv\Scripts\activate (Windows) or source venv/bin/activate (mac/linux)
3. pip install -r requirements.txt
4. set environment variables as needed (DATABASE_URL, SECRET_KEY)
5. python run.py

This is a starter scaffold. Continue implementing appointment and record management features.
